System.config({
  //use typescript for compilation
  transpiler: 'typescript',
  //typescript compiler options
  typescriptOptions: {
    emitDecoratorMetadata: true
  },
  //map tells the System loader where to look for things
  map: {
    app: "./src"
  },
  //packages defines our app package
  packages: {
    app: {
      main: './main.ts',
      defaultExtension: 'ts'
    }
  }
});

// Code goes here
//   <script language="javascript">
function check(form){
      
  if(form.userid.value == "john" && form.psswrd.value=="123"){
    window.open('https://www.youtube.com/watch?v=X1ag8kapwUk')
        
  }
  else{
    alert("the username and/or password you entered are incorrect")
  }
        
}