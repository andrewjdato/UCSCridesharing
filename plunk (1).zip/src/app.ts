import {Component, Directive, Output, EventEmitter} from 'angular2/core'
import {ROUTER_DIRECTIVES, RouteConfig} from 'angular2/router';



@Component({
  selector: 'home',
  directives: [],
  template: `
  <h1 class="text-center">Slug Ride</h1>
    <form name="login">
      <div class= "login text-center">
        <input type = "text" placeholder="Username/UCSC Email" name="userid"><br>
        <input type = "password" placeholder="Password" name="psswrd"><br>
        <input type = "button" onclick="check(this.form)" value="Login"><br>
        
      </div>
    </form>
`
})
export class homeComponent {
}

@Component({
  selector: 'register',
  directives: [],
  template: `
  <h1 class="text-center">Register</h1>
  <body>
    <div class= "text-center">
      <input type = "text" placeholder="Username/UCSC Email" name="userid"><br>
      <input type = "password" placeholder="Password" name="psswrd"><br>
      <input type = "password" placeholder="Verify Password" name="psswrd"><br>
      <input type = "button" value="Submit"><br>
    </div>
  </body>
`
})
export class registerComponent {
} 

@Component({
  selector: 'forgot',
  directives: [],
  template: `
  <h1 class="text-center">Password Recovery</h1>
  <body>
    <div class= "text-center">
      <input type = "text" placeholder="Username/UCSC Email" name="userid"><br>
      <input type = "button" value="Submit"><br>
    </div>
  </body>
`
})
export class forgotComponent {
} 



@Component({
  selector: 'page1',
  directives: [ROUTER_DIRECTIVES],
  template: `
  <router-outlet></router-outlet>
  <div class= "text-center">
    <a href="#" [routerLink]="['/Page2','Register']" >Register</a> <br> 
    <a href="#" [routerLink]="['/Page2','Forgot']" >Forgot Password?</a>  
  </div>
`
})

@RouteConfig([
    {path: '/home', name : 'Home' , component : homeComponent, useAsDefault: true},
])
export class Page1 {
}

@Component({
  selector: 'page2',
  directives: [ROUTER_DIRECTIVES],
  template: `
  <!-- <h2>page2</h2> -->

  <router-outlet></router-outlet>
  <div class= "text-center">
    <a href="#" [routerLink]="['/Page1','Home']" >Back</a> <br> 
  </div>
`
})
@RouteConfig([
    {path: '/register', name : 'Register' , component : registerComponent, useAsDefault: true},
    {path: '/forgot', name : 'Forgot' , component : forgotComponent},
])
export class Page2 {
}


@Component({
  selector: 'my-app',
  directives: [ROUTER_DIRECTIVES],
  template: `
  <router-outlet></router-outlet>
`
})
@RouteConfig([
    {path: '/page1/...',name : 'Page1' , component : Page1 , useAsDefault: true },
    {path: '/page2/...', name : 'Page2' , component : Page2 },
])
export class App {
  constructor() {
    this.name = 'Angular2';
  }  
}