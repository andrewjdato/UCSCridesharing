System.config({
  //use typescript for compilation
  transpiler: 'typescript',
  //typescript compiler options
  typescriptOptions: {
    emitDecoratorMetadata: true
  },
  //map tells the System loader where to look for things
  map: {
    app: "./src"
  },
  //packages defines our app package
  packages: {
    app: {
      main: './main.ts',
      defaultExtension: 'ts'
    }
  }
});

// Code goes here

//   <script language="javascript">
//the function check is going to check that the username & password in the login screen match
//check is used in the home component
function check(form){
      
  if(form.userid.value == "john" && form.psswrd.value=="123"){
    window.open('https://www.youtube.com/watch?v=X1ag8kapwUk')
        
  }
  else{
    alert("the username and/or password you entered are incorrect")
  }
        
} 

//checkRegister function is used to make sure that the user is not registering his/her account with an email already in use
//checkRegister is used in the register component
function checkRegister(form){
  //to do: check with server to make sure username is not in use
  if(form.userid.value == "john"){
   //code goes here
    
  }else{
   alert("The username is already in use, try the forgot password button in order to receive your password through email")
  }
  if(form.psswrd.value != form.psswrdVerify.value){
    alert("The passwords entered do not match")
  }
  
}

//checkForgot checks to make sure that the username entered in the Forgot Password page is an email associated with an account
function checkForgot(form){
  
  //todo: check server to make sure email is associated and send an email check
  if(form.userid.value == "john"){
    alert("This email is associated with an account")
    
  }else{
    alert("This email is not associated with an account")
  }

}