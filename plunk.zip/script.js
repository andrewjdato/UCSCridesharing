// Code goes here
//   <script language="javascript">
      function check(form){
        
        if(form.userid.value == "john" && form.psswrd.value=="123"){
          window.open('https://www.youtube.com/watch?v=X1ag8kapwUk')
          
        }
        else{
          alert("the username and/or password you entered are incorrect")
        }
        
      }
